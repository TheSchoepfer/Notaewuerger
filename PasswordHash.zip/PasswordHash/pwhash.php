<?php 

$hash = password_hash("Passw0rd!", PASSWORD_DEFAULT);

echo $hash;

?>