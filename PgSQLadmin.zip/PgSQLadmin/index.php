<? die(header('Location: http://phppgadmin.notaewuerger.bplaced.net/')); ?>
